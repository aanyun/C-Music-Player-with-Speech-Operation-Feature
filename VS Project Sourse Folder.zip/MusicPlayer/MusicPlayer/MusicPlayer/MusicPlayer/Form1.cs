﻿using System;
using System.Windows.Forms;
using System.IO;
using System.Drawing;
using System.Speech.Recognition;
using SpeechLib;
namespace MusicPlayer
{
    public partial class Form1 : Form
   {
        private SpeechRecognitionEngine SRE = new SpeechRecognitionEngine();
        String previousWord1 = "sss";
        String previousWord2 = "aaa";
        public Form1()
        {
            Control.CheckForIllegalCrossThreadCalls = false;
            InitializeComponent();
        }

        static WMPLib.WindowsMediaPlayer Player = new WMPLib.WindowsMediaPlayer();
        MPlayer MyPlayer = new MPlayer(Player);
        int a = 0;
        int p = 1;
        int s = 0;
        private void Form1_Load(object sender, EventArgs e)
        {

            label1.Visible = false;
            //playStatechange事件:该事件是在歌曲的播放状态改变时，当该事件引发以后
            Player.PlayStateChange += new WMPLib._WMPOCXEvents_PlayStateChangeEventHandler(playstate);
           
            
        }
        
        #region 控制音乐连续播放
        //判断音乐是否播放到最后
        private void playstate(int NewState)
        {
            if (MyPlayer.playstate == WMPLib.WMPPlayState.wmppsMediaEnded)
            {
                timer1.Start();
            }
        }
      

        private void timer1_Tick_1(object sender, EventArgs e)
        {
            
            timer1.Stop();

            int selectnum = 0;

            if (顺序播放ToolStripMenuItem.Checked) { selectnum = MyPlayer.NextPlay(0); p = selectnum-1 ; }

            else if (单曲循环ToolStripMenuItem.Checked) selectnum = MyPlayer.NextPlay(2);

            else if (全部循环ToolStripMenuItem.Checked)
            {selectnum = MyPlayer.NextPlay(1);
            if (selectnum != 1) p = selectnum - 1;
            else p = 2;
            }

            else if (随机播放ToolStripMenuItem.Checked)
            {
                p = MyPlayer.CurrentPlay;

                selectnum = MyPlayer.NextPlay(3);

            }

            if (selectnum != 0)
            {
                this.listView1.Items[p-1].Selected = false;
                this.listView1.Items[selectnum - 1].Selected = true;
                this.Text = this.listView1.Items[selectnum - 1].SubItems[1].Text.Trim();
                
                MyPlayer.play(selectnum);
            }
        }
        #endregion

        #region 任务栏中的图片菜单
        private void 退出ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            GC.Collect();
            this.Close();
        }

        private void 隐藏ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (隐藏ToolStripMenuItem.Text.ToString().Trim()=="隐藏")
            {
                隐藏ToolStripMenuItem.Text = "显示";
                this.Visible = false;
            }
            else
            {
                隐藏ToolStripMenuItem.Text = "隐藏";
                this.Visible = true;
            }
        }
        #endregion

        #region 菜单栏
        private void 添加文件ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (openFileDialog1.ShowDialog()==DialogResult.OK)
            {
                string[] strFile = this.openFileDialog1.FileNames;
                for (int i = 0; i < strFile.Length; i++)
                {
                    FileInfo fileInfo = new FileInfo(strFile[i]);
                    AddFileView(fileInfo);
                }
            }
        }

        private void 添加文件夹ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (folderBrowserDialog1.ShowDialog()==DialogResult.OK)
            {
                DirectoryInfo dir = new DirectoryInfo(this.folderBrowserDialog1.SelectedPath);
                foreach (FileInfo fileInfo in dir.GetFiles("*.mp3"))
                {
                    AddFileView(fileInfo);
                }
                foreach (FileInfo fileInfo in dir.GetFiles("*.wma"))
                {
                    AddFileView(fileInfo);
                }
                foreach (FileInfo fileInfo in dir.GetFiles("*.wav"))
                {
                    AddFileView(fileInfo);
                }
            }
        }
        
        private void AddFileView(FileInfo fileInfo) 
        {
            MyPlayer.AddFile(fileInfo.FullName);
            ListViewItem item = new ListViewItem();
            item.Text = MyPlayer.NumOfMusic.ToString();
            item.SubItems.Add(fileInfo.Name);
            item.SubItems.Add(fileInfo.FullName);
            this.listView1.Items.Add(item);
        }

        #endregion
    //    private void listView1_Click(object sender, EventArgs e)
      //  { int iSel=this.listView1.SelectedItems[0].Index;
        //this.listView1.Items[iSel].Checked = true;
       // }
        //播放
       
        private void listView1_DoubleClick(object sender, EventArgs e)
        {
            if (this.listView1.SelectedItems.Count>0)
            {
                toolStripButton暂停.Text = "Pause";
                toolStripButton暂停.BackgroundImage =  imageList1.Images[1];
              
                //获取歌曲的索引+1
                int iSel = this.listView1.SelectedItems[0].Index + 1;
                this.Text=listView1.SelectedItems[0].SubItems[1].Text.ToString().Trim();
                if (iSel<=MyPlayer.NumOfMusic)
                {
                    MyPlayer.play(iSel);
                    timer2.Enabled = true;
                    
                    
                }
            }
        }
        //任务栏图标
        private void notifyIcon1_MouseMove(object sender, MouseEventArgs e)
        {
            this.notifyIcon1.Text = this.Text.ToString().Trim();
        }

        #region 播放模式
        /// <summary>
        /// 0顺序播放 | 1单曲循环播放 | 全部
        /// </summary>
        bool boRandom = false;
        private void 顺序播放ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            顺序播放ToolStripMenuItem.Checked = true;
            单曲循环ToolStripMenuItem.Checked = false;
            全部循环ToolStripMenuItem.Checked = false;
            随机播放ToolStripMenuItem.Checked = false;
            boRandom = false;
        }

        private void 单曲循环ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            顺序播放ToolStripMenuItem.Checked = false;
            单曲循环ToolStripMenuItem.Checked = true;
            全部循环ToolStripMenuItem.Checked = false;
            随机播放ToolStripMenuItem.Checked = false;
            boRandom = false;
        }

        private void 全部循环ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            顺序播放ToolStripMenuItem.Checked = false;
            单曲循环ToolStripMenuItem.Checked = false;
            全部循环ToolStripMenuItem.Checked = true;
            随机播放ToolStripMenuItem.Checked = false;
            boRandom = false;
        }

        private void 随机播放ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            顺序播放ToolStripMenuItem.Checked = false;
            单曲循环ToolStripMenuItem.Checked = false;
            全部循环ToolStripMenuItem.Checked = false;
            随机播放ToolStripMenuItem.Checked = true;
            boRandom = true;
        }
        #endregion

        #region 选择歌曲


        private void toolStripButton上一首_Click(object sender, EventArgs e)
        {
            if (MyPlayer.CurrentPlay > 0)
            {
                toolStripButton暂停.Text = "Pause";
                toolStripButton暂停.BackgroundImage = imageList1.Images[1];
                a = MyPlayer.CurrentPlay;

                if (boRandom)
                {

                    int b = p;

                    this.listView1.Items[a - 1].Selected = false;
                    this.listView1.Items[b - 1].Selected = true;
                    this.listView1.Items[b - 1].EnsureVisible();
                    this.Text = this.listView1.Items[b - 1].SubItems[1].Text.ToString().Trim();
                    MyPlayer.play(p);

                    p = a;
                }
                else
                {
                    if (this.listView1.SelectedItems.Count > 0)
                    {

                        if ((a - 2) >= 0)
                        {
                            this.listView1.Items[a - 1].Selected = false;
                            this.listView1.Items[a - 2].Selected = true;
                            this.listView1.Items[a - 2].EnsureVisible();
                            this.Text = this.listView1.Items[a - 2].SubItems[1].Text.ToString().Trim();
                            MyPlayer.play(a - 1);

                            a = a - 1;
                        }
                    }
                }
            }
        }

        private void toolStripButton下一首_Click(object sender, EventArgs e)
        {
            if (MyPlayer.CurrentPlay > 0)
            {
                toolStripButton暂停.Text = "Pause";
                toolStripButton暂停.BackgroundImage = imageList1.Images[1];
                a = MyPlayer.CurrentPlay;


                if (boRandom)
                {
                    //          int iMinValue = 1;
                    //          if (this.listView1.SelectedItems.Count>0)
                    //        {
                    //          iMinValue = this.listView1.SelectedItems[0].Index + 1;
                    //    }
                    Random ran = new Random();
                    int i = this.listView1.Items.Count;
                loop:
                    int b = ran.Next(1, i);
                    if (b == MyPlayer.CurrentPlay)
                    {
                        goto loop;
                    }
                    this.listView1.Items[a - 1].Selected = false;
                    this.listView1.Items[b - 1].Selected = true;
                    this.listView1.Items[b - 1].EnsureVisible();
                    this.Text = this.listView1.Items[b - 1].SubItems[1].Text.ToString().Trim();
                    MyPlayer.play(b);

                    p = a;
                }
                else
                {
                    if (this.listView1.SelectedItems.Count >= 0)
                    {
                        if (a > 0)
                        {
                            if ((a + 1) <= MyPlayer.NumOfMusic)
                            {
                                this.listView1.Items[a - 1].Selected = false;
                                this.listView1.Items[a].Selected = true;
                                this.listView1.Items[a].EnsureVisible();
                                this.Text = this.listView1.Items[a].SubItems[1].Text.ToString().Trim();
                                MyPlayer.play(a + 1);
                                p = a;
                            }
                            if (a == MyPlayer.NumOfMusic)
                            {
                                this.listView1.Items[a - 1].Selected = false;
                                a = 1;
                                this.listView1.Items[0].Selected = true;
                                this.listView1.Items[0].EnsureVisible();
                                this.Text = this.listView1.Items[0].SubItems[1].Text.ToString().Trim();
                                MyPlayer.play(1);

                                p = a;
                            }
                        }

                    }
                }
            }
        }

       
        #endregion

        #region 删除文件
        private void 删除重复ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            System.Collections.Hashtable hasFile = new System.Collections.Hashtable();
           
                for (int i = 0; i < this.listView1.Items.Count; i++)
                {
                    if (hasFile.Contains((object)this.listView1.Items[i].SubItems[1].Text.ToString()))
                    {
                        this.listView1.Items[i].Remove();
                        MyPlayer.DelFile(i + 1);
                    }
                    else
                    {
                        hasFile.Add((object)this.listView1.Items[i].SubItems[1].Text.ToString(), "");
                    }
                }
            }
  //      private void 选中的文件ToolStripMenuItem_Click(object sender, EventArgs e)
    //    {
      //      if (this.listView1.SelectedItems.Count > 0)
        //    {
          //      int i = this.listView1.SelectedItems[0].Index;
            //    this.listView1.Items[i].Remove();
              //  for (int d = i; d < this.listView1.Items.Count; d++)
                //{
                  //  this.listView1.Items[d].Text = Convert.ToString(d + 1);
                //}
            //    MyPlayer.DelFile(i + 1);
          //  }
        //}

   private void 选中的文件ToolStripMenuItem_Click(object sender, EventArgs e)
      {
          foreach (ListViewItem item in this.listView1.SelectedItems)
          {
              int a = this.MyPlayer.CurrentPlay;
              string b = Convert.ToString(a);
              if (!item.Text.Equals(b))
                  {
                   item.Remove();

                      MyPlayer.DelFile(item.Index + 1);
                      
                  }
              }

          for (int d = 0; d < this.listView1.Items.Count; d++)
          {
              this.listView1.Items[d].Text = Convert.ToString(d + 1);
          }
       
           }
        

       private void 错误的文件ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < this.listView1.Items.Count; i++)
            {
                if (!File.Exists(this.listView1.Items[i].SubItems[2].Text.ToString().Trim()))
                {
                    this.listView1.Items[i].Remove();
                    MyPlayer.DelFile(i + 1);
                }
            }
            for (int i = 0; i < this.listView1.Items.Count; i++)
            {
                this.listView1.Items[i].Text = Convert.ToString(i + 1);
            }
            
        }

        private void 全部文件ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            for (int i = this.listView1.Items.Count-1; i >=0; i--)
            {
                this.listView1.Items[i].Remove();
                MyPlayer.DelFile(i + 1);
            }
        }
        #endregion

        //暂停
        private void toolStripButton暂停_Click(object sender, EventArgs e)
        {
            if (MyPlayer.CurrentPlay > 0)
            {
                if (toolStripButton暂停.Text == "Pause")
                {
                    Player.controls.pause();
                    toolStripButton暂停.Text = "Play";
                    toolStripButton暂停.BackgroundImage = imageList1.Images[0];
                }
                else
                {
                    Player.controls.play();
                    toolStripButton暂停.Text = "Pause";
                    toolStripButton暂停.BackgroundImage = imageList1.Images[1];
                }
            }

           if(MyPlayer.CurrentPlay<=0&&listView1.Items.Count>0)
            {
                MyPlayer.play(1); timer2.Enabled = true; toolStripButton暂停.Text = "Pause";
                toolStripButton暂停.BackgroundImage = imageList1.Images[1];
            }
        }

        #region 拖放歌曲
        DragEventArgs ex;
        private void listView1_DragEnter(object sender, DragEventArgs e)
        {
            ex = e;
        }

        private void listView1_MouseEnter(object sender, EventArgs e)
        {
            this.listView1_DragDrop(sender, ex);
            ex = null;   
        }

        private void listView1_DragDrop(object sender, DragEventArgs e)
        {
            try
            {
                if (e.Data.GetDataPresent(DataFormats.FileDrop))//判断拖放的数据是否为文件
                {
                    string[] files = (string[])(e.Data.GetData(DataFormats.FileDrop));//将拖放过来的文件赋值给数组
                    for (int i = 0; i < files.Length; i++)
                    {
                        FileInfo fileInfo = new FileInfo(files[i]);
                        string fileType = fileInfo.Name.Substring(fileInfo.Name.LastIndexOf(".") + 1);
                        if (fileType!="mp3"&&fileType!="wma"&&fileType!="wav")
                        {
                            return;
                        }
                        AddFileView(fileInfo);
                    }
                }
            }
            catch
            {
                
            }
        }
        #endregion
        //音量
        private void trackBar1_Scroll(object sender, EventArgs e)
        {
            Player.settings.volume = (trackBar1.Value) * 2;
        }
        

        private void toolStripButton静音_Click(object sender, EventArgs e)
        {
           
            if (toolStripButton静音.Text =="Mute")
            {
              Player.settings.mute = true;
              toolStripButton静音.Text = "Regain";
            }
            else
            {
                Player.settings.mute = false;
                toolStripButton静音.Text = "Mute";
            }
        }

        private void label2_Click(object sender, EventArgs e)
        {
            if (this.listView1.SelectedItems.Count > 0)
            {
                //获取歌曲的索引+1
                int iSel = this.listView1.SelectedItems[0].Index + 1;
                this.Text = listView1.SelectedItems[0].SubItems[1].Text.ToString().Trim();
                if (iSel <= MyPlayer.NumOfMusic)
                {
                    MyPlayer.play(iSel);
                }
            }
        }

     

      private void trackBar2_Scroll(object sender, EventArgs e)
        {
           
           MyPlayer.setNowPostion(this.trackBar2.Value);
                

       }
       private void trackBar2_MouseUp(object sender, MouseEventArgs e)
       {
           Player.controls.play();
        }

       private void timer2_Tick(object sender, EventArgs e)
       {
           this.trackBar2.Maximum = (int)MyPlayer.LengthAudio();
           trackBar2.Value = (int) MyPlayer.NowPostion();
       }

       private void listView1_SelectedIndexChanged(object sender, EventArgs e)
       {

       }

       private void StartRec_Click(object sender, EventArgs e)
       {
           if (s == 1)
           {
               label1.Visible = false;
               SpVoice voice = new SpVoice();//SAPI 5.4
               voice.Voice = voice.GetVoices(string.Empty, string.Empty).Item(1);
               voice.Speak("Closing speech recognition");
               SRE.RecognizeAsyncStop(); s = 0;
               StartRec.BackgroundImage = imageList1.Images[2];
               toolTip1.SetToolTip(StartRec, "Open Speech Recognition");
              
               return;
           }
           if (s == 0)
           {
               label1.Visible = true;
               SpVoice voice = new SpVoice();//SAPI 5.4
               voice.Voice = voice.GetVoices(string.Empty, string.Empty).Item(1);
               voice.Volume = 100;
               voice.Speak("Welcome to Music Player. It is starting Speech Recognition. Can I help you?");
               SRE.SetInputToDefaultAudioDevice(); //载入语音识别引擎
               GrammarBuilder GB = new GrammarBuilder();
               //GB.Append("选择");
               GB.Append(new Choices(new string[] { "play mode","order cycle","single repeat","all repeat","shuffle","add music", "add folder", "delete", "delete all files", "order cycle", "single repeat", "all repeat", "shuffle", "play","start", "play the music", "music", "stop", "pause", "next", "next one", "the next", " the last", "previous", "last", "mute", "silent", "exit", "exit system", "close", "close system", "recover", "regain" }));
               Grammar G = new Grammar(GB);
               G.SpeechRecognized += new EventHandler<SpeechRecognizedEventArgs>(G_SpeechRecognized);
               SRE.LoadGrammar(G);
               SRE.RecognizeAsync(RecognizeMode.Multiple);
               s=1;
               StartRec.BackgroundImage = imageList1.Images[3];
               toolTip1.SetToolTip(StartRec, "Closing Speech Recognition");
               return;
               
           }
          
           
        

       }

       void G_SpeechRecognized(object sender, SpeechRecognizedEventArgs e)
       {
           Text = e.Result.Text;
           switch (e.Result.Text)
           {
               case "play mode":
                   SpVoice voice = new SpVoice();//SAPI 5.4
                   voice.Voice = voice.GetVoices(string.Empty, string.Empty).Item(1);
                   voice.Speak("You can choose order cycle,single repeat,all repeat and shuffle");
                   break;
               case "order cycle":
                   this.顺序播放ToolStripMenuItem.PerformClick();
                   SpVoice voice1 = new SpVoice();//SAPI 5.4
                       voice1.Voice = voice1.GetVoices(string.Empty, string.Empty).Item(1);
                       voice1.Speak("Now is Order cycle play mode");
                   break;
               case "single repeat":
                   this.单曲循环ToolStripMenuItem.PerformClick();
                   SpVoice voice2 = new SpVoice();//SAPI 5.4
                       voice2.Voice = voice2.GetVoices(string.Empty, string.Empty).Item(1);
                       voice2.Speak("Now is single repeat play mode");
                   break;
               case "all repeat":
                   this.全部循环ToolStripMenuItem.PerformClick();
                   SpVoice voice3 = new SpVoice();//SAPI 5.4
                       voice3.Voice = voice3.GetVoices(string.Empty, string.Empty).Item(1);
                       voice3.Speak("Now is all repeat play mode");
                   break;
               case "shuffle":
                   this.随机播放ToolStripMenuItem.PerformClick();
                   SpVoice voice4 = new SpVoice();//SAPI 5.4
                       voice4.Voice = voice4.GetVoices(string.Empty, string.Empty).Item(1);
                       voice4.Speak("Now is Order cycle play mode");
                   break;
               case "play":
               case "music":
               case "start":
               case "play the music":
               case "play music":
                   if (previousWord1.Equals("play")){break;}
                   else
                   {this.toolStripButton暂停.PerformClick();
                   previousWord1 = e.Result.Text;
                   break;
                   }
               case "pause":
               case "stop":
                   if (previousWord1.Equals("pause")) { break; }
                   else
                   {
                       this.toolStripButton暂停.PerformClick();
                       previousWord1 = e.Result.Text;
                       break;
                   }
               case "previous":
               case "last":
               case "the last":
                   this.toolStripButton上一首.PerformClick();
                   break;
               case "next":
               case "the next":
               case "next one":
                   this.toolStripButton下一首.PerformClick();
                   break;
               case "mute":
               case "silent":
               case "silence":
                   if (previousWord2.Equals("mute")) { break; }
                   else
                   {
                       this.toolStripButton静音.PerformClick();
                       previousWord2 = e.Result.Text;
                       break;
                   }
                   
               case "regain":
               case "recover":
                   if (previousWord2.Equals("regain")) { break; }
                   else
                   {
                       this.toolStripButton静音.PerformClick();
                       previousWord2 = e.Result.Text;
                       break;
                   }
               case "close system":
               case "exit":
               case "close":
               case "exit system":
                   this.Close();
                   break;
               default:
                   {
                       SpVoice voice5 = new SpVoice();//SAPI 5.4
                       voice5.Voice = voice5.GetVoices(string.Empty, string.Empty).Item(1);
                       voice5.Speak("Cannot Recognize what you said");
                       break;
                   }
           }
       }

       private void label1_Click(object sender, EventArgs e)
       {

       }

     


      
       
    }
}
