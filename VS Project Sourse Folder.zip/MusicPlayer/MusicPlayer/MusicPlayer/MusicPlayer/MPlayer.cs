using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Net;


namespace MusicPlayer
{
    public partial class MPlayer
    {
        private WMPLib.WindowsMediaPlayer myPlayer = new WMPLib.WindowsMediaPlayer();//����Window Mediaplayer�Ľӿ�
        private string[] playList = new string[10000];//�������
        private int numOfMusic = 0;//�û���������
        private static int currentPlay = 0;//��ǰ���ڲ��ŵ����ֵı��
        /// <summary>
        /// ��ǰ���ŵ��б�
        /// </summary>
        public int CurrentPlay
        {
            get { return currentPlay; }
            set { currentPlay = value; }
        }
       
        public MPlayer(WMPLib.WindowsMediaPlayer mediaPlayer)
        {
            myPlayer = mediaPlayer;
            playList = new string[10000];
            numOfMusic = 0;
        }
        /// <summary>
        /// �ܹ��ж����׸�
        /// </summary>
        public int NumOfMusic
        {
            get
            {   
                return numOfMusic;
            }
        }
        /// <summary>
        ///����״̬
        /// </summary>
        public WMPLib.WMPPlayState playstate
        {
            get
            {   
                return myPlayer.playState;
            }
        }
        /// <summary>
        /// �����б���ָ���ĸ���
        /// </summary>
        /// <param name="num"></param>
        /// <returns></returns>
        public string PlayList(int num)
        {
            return playList[num];
        }

        /// <summary>
        /// ���Ӹ���
        /// </summary>
        /// <param name="path"></param>
        public void AddFile(string path)
        {
            if (numOfMusic < 10000)
            {
                numOfMusic++;
                playList[numOfMusic] = path;
            }
        }
        /// <summary>
        /// ɾ������
        /// </summary>
        /// 
        /// <param name="selectNum"></param>
        public void DelFile(int selectNum)
        {
            for(int i = selectNum; i <= numOfMusic - 1; i++)
            {
                playList[i] = playList[i + 1];
            }
            numOfMusic--;
        }
       public double LengthAudio()
       {
           return myPlayer.currentMedia.duration;
        }
       public double NowPostion()
        {
           return myPlayer.controls.currentPosition;
       }
       public void setNowPostion(int position)
       {    
            myPlayer.controls.currentPosition = (double)position;
        }
        /// <summary>
        ///   ����
        /// </summary>
        /// <param name="selectNum"></param>
        
        public void play(int selectNum)
        {   
            myPlayer.URL = playList[selectNum];
            currentPlay = selectNum;
           
        }
        /// <summary>
        /// type = 0 ˳��   type = 1 �ظ�����ȫ��    type = 2 �ظ�����һ��   type = 3 �������
        /// </summary>
        /// <param name="type"></param>
        /// <returns></returns>
        public int NextPlay(int type)
        {
            switch (type)
            {
                case 0:
                    currentPlay++;
                    if (currentPlay > numOfMusic) return 0;
                    else return currentPlay;
                case 1:
                    currentPlay++;
                    if (currentPlay > numOfMusic) return 1;
                    else return currentPlay;
                case 2:
                    return currentPlay;
                case 3:
            //        Random rdm = new Random(unchecked((int)DateTime.Now.Ticks));
            //        currentPlay = rdm.Next() % numOfMusic;
              //      if (currentPlay == 0) return numOfMusic;
                //    else return currentPlay;
                Random ran = new Random();
                int i = numOfMusic;
            loop:
                int b = ran.Next(1, i);
                if (b==currentPlay)
                {
                    goto loop;
                }
                return b;
                default:
                    return 0;
            }
        }
    }
}
